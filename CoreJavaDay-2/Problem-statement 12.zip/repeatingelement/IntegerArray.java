package com.example.repeatingelement;

import java.util.HashSet;
import java.util.Scanner;

public class IntegerArray {

	public static void main(String[] args) {

	Scanner sc = new Scanner(System.in);
    System.out.println("Enter the length of array : ");
    int[] arr = new int[sc.nextInt()];
    System.out.println("Enter the array values : ");
    for (int i = 0; i < arr.length; i++) {
        arr[i] = sc.nextInt();
    }
        int temp=-1;
		HashSet<Integer>hs=new HashSet<>();
		for(int i=arr.length-1; i>=0;i--)
		{
			if(hs.contains(arr[i])) {
				temp=i;
			}
			else
			{
				hs.add(arr[i]);
			}
		}
		if(temp!=-1) {
			System.out.println("First repeated element is: "+arr[temp]);
		}
		else {
			System.out.println("First repeated element not found.");
		}
	}

    
}

