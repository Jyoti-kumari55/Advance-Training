package com.example.pharmaceutical.company;


public class Medicine {

	public void displayLabel() {
		System.out.println("Comapany:Globex Pharma");
		System.out.println("Address: Pune");
	}
}
class  Tablet extends Medicine 
{
    public void displayLabel()
    {
    	System.out.println("store in a cool and dry place:");	
    }
    
    class Ointment extends Medicine
    {
   	 public void displayLabel()
   	 {
   		 System.out.println("For external use only..stay away it from children");
   	 }
   	 
   	class Syrup extends Medicine{

   	 public void displayLabel()
   	 {
   		 System.out.println("Consumption is directed by the Physician:");
   	 }
  }

	
    }
}
