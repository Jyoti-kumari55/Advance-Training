package com.example.multithreading;

public class CounterTh {

	public static void main(String args[])

	{

	Counter counter = new Counter(30);

	counter.run();

	}

}
