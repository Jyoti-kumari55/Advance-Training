package com.example.rectangle.problem;

public class Rectangle {
private int length;
private int breadth;
private int area;
public int getLength() {
	return length;
}
public void setLength(int length) {
	this.length = length;
}
public int getBreadth() {
	return breadth;
}
public void setBreadth(int breadth) {
	this.breadth = breadth;
}
public int getArea() {
	return area;
}
public void setArea(int area) {
	this.area = area;
}
@Override
public String toString() {
	return "Rectangle [length=" + length + ", breadth=" + breadth + ", area=" + area + "]";
}
public Rectangle() {
	
}
public Rectangle(int length,int breadth) {
this.length=length;
this.breadth=breadth;
}

public void RectangleArea(int length,int breadth) {
	area=length*breadth;
}
public void DisplayAllInformationOfRectangle() {
	System.out.println("Length of rectangle is ->" +length);
	System.out.println("Breadth of rectange is ->" +breadth);
	System.out.println("Area of rectangle is ->" +area);
}
public void displayAreaOfTestRectangle() {
	
	System.out.println("Length = "+length);
	System.out.println("Beadth = "+breadth);
	System.out.println("Area = "+length*breadth);
	System.out.println();
}
public static void main(String[] args) {
	// TODO Auto-generated method stub

//	Rectangle obj = new Rectangle(3,5);
//	obj.areaOfRectangle(3, 5);
//	obj.displayAllInformation();
	Rectangle obj = new Rectangle();
	obj.setLength(4);
	obj.setBreadth(6);
	obj.setArea(4*6);
	System.out.println("Length : "+obj.getLength());
	System.out.println("Breadth : "+obj.getBreadth());
	System.out.println("Area of recatange ->"+obj.getArea());
	//System.out.println(obj.length);
	//System.out.println(obj.breadth);
}
}
