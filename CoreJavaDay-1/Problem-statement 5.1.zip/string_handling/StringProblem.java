package com.example.string_handling;

public class StringProblem {

public static void main(String[] args) {
			
		
		String text= "JAVA is Simple";
		
		//Replace text to UpperCase :-
		System.out.println(text.toUpperCase()); 
		
		//Replace text to lowerCase :-
		System.out.println(text.toLowerCase()); 
		
		//Replace text into characters :-
		String[] words=text.split("\\s");	
		for(String w:words){  
			System.out.print(w.charAt(0)); 
			System.out.print(" ");
		}
		System.out.println(" ");
		
		
		String[] words1=text.split("\\s"); // Change order 
		for(String w:words1){  
			System.out.println(w); 
		}
		
		//String Builder reverse
		StringBuilder words2= new StringBuilder("JAVA is Simple");
		
		Object words21;
		System.out.println("String = " + words2.toString());
		StringBuilder reverseStr = words2.reverse();
		System.out.println("Reverse String = " + reverseStr.toString());
		
		//Total Length
		System.out.println("length of string " + text.length());
	}
}
