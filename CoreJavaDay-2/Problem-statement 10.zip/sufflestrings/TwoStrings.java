package com.example.sufflestrings;

public class TwoStrings {

	public static boolean Shuffle(String first, String second, String third)
	{
	if (first.length() == 0 && second.length() == 0 && third.length() == 0) {
	return true;
	}
	if (third.length() == 0) {
	return false;
	}
	if (first.length() != 0 && third.charAt(0) == first.charAt(0)) {
	return Shuffle(first.substring(1), second, third.substring(1));
	}
	if (second.length() != 0 && third.charAt(0) == second.charAt(0)) {
	return Shuffle(first, second.substring(1), third.substring(1));}
	return false;
	}
	 public static void main(String[] args)
	{
	String first = "pqr";
	String second = "lmno";
	String third = "plmrqon";
	if (Shuffle(first, second, third)) {
	System.out.println("True: third string is valid shuffle of first and second string.");
	}
	else {
	System.out.println("false: third string is NOT a valid shuffle of first and second string.");
	}
	String first1 = "abc" ;
	String second1 = "def";
	String third1 = "dabecf";
	if (Shuffle(first1, second1, third1)) {
	System.out.println("true: third string is valid shuffle of first and second string.");
	}
	else {
	System.out.println("false: third string is NOT a valid shuffle of first and second string.");
	}
	
	}

}
