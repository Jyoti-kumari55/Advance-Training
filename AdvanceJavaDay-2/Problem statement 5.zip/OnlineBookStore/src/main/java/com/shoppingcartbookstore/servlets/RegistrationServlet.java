package com.shoppingcartbookstore.servlets;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.shoppingcartbookstore.dao.UserDao;
import com.shoppingcartbookstore.dbutils.DbUtils;
import com.shoppingcartbookstore.dbutils.DbUtils.jdbcconnection;
import com.shoppingcartbookstore.entity.User;

/**
 * Servlet implementation class RegistrationServlet
 */
public class RegistrationServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public RegistrationServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter out= response.getWriter();
		response.setContentType("text/html");
		
		
			String first_Name=request.getParameter("fname");
			String address=request.getParameter("address");
			String email=request.getParameter("uemail");
			String user_Name=request.getParameter("name");
			String password=request.getParameter("upass");
//			user object save all data to user object
			
			User user=new User(first_Name, address,  email,  user_Name,  password);
           
			//			user dao object
			UserDao dao = null;
			try {
				dao = new UserDao(jdbcconnection.getConnection());
			} catch (ClassNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			if(dao.saveUser(user)) {
				out.println("Register");
				response.sendRedirect("login.jsp");

				
			}
			else {
				out.println("Registratin failed!!");
			}
		}
		
	


}
