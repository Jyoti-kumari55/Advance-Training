package com.shoppingcartbookstore.entity;

import java.sql.Timestamp;

public class User
    {
	
		String first_Name;
		String address;
		String email;
		String user_Name;
		String password;
		Timestamp registration_date;
		
		public User() {
		}

		public String getFirst_Name() {
			return first_Name;
		}

		public void setFirst_Name(String first_Name) {
			this.first_Name = first_Name;
		}

		public String getAddress() {
			return address;
		}

		public void setAddress(String address) {
			this.address = address;
		}

		public String getEmail() {
			return email;
		}

		public void setEmail(String email) {
			this.email = email;
		}

		public String getUser_Name() {
			return user_Name;
		}

		public void setUser_Name(String user_Name) {
			this.user_Name = user_Name;
		}

		public String getPassword() {
			return password;
		}

		public void setPassword(String password) {
			this.password = password;
		}

		public Timestamp getRegistration_date() {
			return registration_date;
		}

		public void setRegistration_date(Timestamp registration_date) {
			this.registration_date = registration_date;
		}
		public User(String first_Name, String address, String email, String user_Name, String password,Timestamp registration_date) 
		{
			this.first_Name = first_Name;
			this.address = address;
			this.email = email;
			this.user_Name = user_Name;
			this.password = password;
			this.registration_date = registration_date;
		}

		public User(String first_Name, String address, String email, String user_Name, String password) {
			super();
			this.first_Name = first_Name;
			this.address = address;
			this.email = email;
			this.user_Name = user_Name;
			this.password = password;
			
		}
		
		}
		


