package com.example.coinproblem;

import java.util.Vector;

public class CoinChangeProblem {

	static int arr[] = {1, 2, 5, 10, 20, 50, 100, 500, 1000, 2000};
		    static int n = arr.length;
		  
		    static void findMin(int V)
		    {
		      
		        Vector<Integer> vecto = new Vector<>();
		  
		         
		        for (int i = n - 1; i >= 0; i--)
		        {
		             
		            while (V >= arr[i]) 
		            {
		                V -= arr[i];
		                vecto.add(arr[i]);
		            }
		        }
		   
		        for (int i = 0; i < vecto.size(); i++)
		        {
		            System.out.println(" " + vecto.elementAt(i));
		        }
		    }
		  
		    
		    public static void main(String[] args) 
		    {
		        int p = 70;
		        System.out.println("Break-down into coins for : " + p );
		        findMin(p);
		        
		        int q = 121;
		        System.out.println("Break-down into coins for : " + q );
		        findMin(q);
		        
		        int r = 2045;
		        System.out.println("Break-down into coins for : " + r );
		        findMin(r);
		        int x = 5678;
		        System.out.println("Break-down into coins for : " + x );
		        findMin(x);
		    }

}
