package com.mycompany.dbutils;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
public class DBUtils {
	

    public static Connection getConnection()throws ClassNotFoundException, SQLException
    {
    	String hostName = "localhost";
    	String dbName = "product";
    	String userName = "root";
    	String password = "javalearn22@";
    	
    	return getConnection(hostName,dbName,userName,password);
    }
    public static Connection getConnection(String hostName,String dbName,String userName,String password) 
    		throws ClassNotFoundException, SQLException{
    	Connection conn = null;
        try{
    	
            Class.forName("com.mysql.cj.jdbc.Driver");
            String connectionURL = "jdbc:mysql://"+hostName+":3306/"+dbName;
            
            conn = DriverManager.getConnection(connectionURL,userName,password);
        }
        catch (SQLException e) {
        	  System.out.println("SQLException: " + e.getMessage());
		}
           return conn;
    }

  //close connection
    public static void closeConnection(Connection conn)
    {
        try{
            conn.close();
        }catch(Exception e){
            e.printStackTrace();
        }
    }

}
        

       
