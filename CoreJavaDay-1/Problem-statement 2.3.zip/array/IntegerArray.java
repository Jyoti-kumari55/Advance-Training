package com.example.array;

import java.util.Scanner;
import java.util.function.BiConsumer;

public class IntegerArray {

	public static void main(String[] args) {  
        //Initialize array  
        Scanner sc = new Scanner(System.in);
        int arr[] = new int[18];
        System.out.println("Enter all the 18 elements :");
        for(int i = 0; i < 18; i++) {
        	arr[i] = sc.nextInt();
        	
        }
        int min = arr[0];
        int max = arr[0];
        int sum = 0;
        for(int i=0; i<arr.length; i++) {
        	if(arr[i]<min)
        		min = arr[i];
        	if(arr[i]>max)
        		max = arr[i];
        	sum =sum + arr[i];
        	
        }
        System.out.println("Larget number :" +max);
        System.out.println("Smallest number :" +min);
        System.out.println("Sum of the numbers :" +sum);
        
        double avg = sum/18;
        System.out.println("Average of the numbers :" +avg);
    }  
}
