package com.example.expression_code;

public class ExpressionParser {

public static void main(String[] args) {
		
		
		String exp= (" 23  +  45  -  (  343  /  12  ) ");
		String[] arr=exp.split("\\s");
		
		for(String arr1:arr){  
			System.out.println(arr1); 
			
		}
   }
}