package com.example.fileHandling;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Scanner;

public class FileDisplay {
	  public static void main(String[] args) throws IOException { 
	Scanner sc = new Scanner(System.in);
	  int Operation = 0;
	String path = "C:\\core_java\\";
		while (true)
		{
			
			System.out.println("Select the below options:-\n"+"1. To display all the existing files  \n"
			+"2. Create and add new file \n"+"3. Exit from the app");
			 Operation = sc.nextInt();
			
			 switch(Operation) {
			 //*****Display all the files*****//
			case 1:
			     File f=new File(path);
			      File filename[]=f.listFiles();
			       for(File ff:filename) { 
				   System.out.println(ff.getName());
				
			}
			       break;
			
		 case 2:
			 //******Create or add new files******//
     Scanner s1 = new Scanner(System.in);
 	
			ArrayList<String> al=new ArrayList<>();
			while(true) {
			System.out.println("Enter the filename to create into the Folder:");
			String File=s1.next();
			String finalname=path+File;
			System.out.println(finalname);
			
			File f1=new File(finalname);
		boolean b=f1.createNewFile();
		if(b!=true) {
			System.out.println("File is already exits in the folder ->" +File);
		}
		else {
			al.add(File);
			System.out.println("File created ->"+File);
			//System.out.println("Collection of files is "+ al);
		}
		break;
			}
				default:
					System.out.println("Oops! please enter a valid key\n"
							+ "Thanks!");
	     }
  }
}
}
