package com.example.linkedlist;

import java.util.LinkedList;
import java.util.Vector;

public class EmployeeCollection{
	
	public static void main(String[] args) {
		LinkedList<Employee> v = addInput();
		display(v);
	}

	private static LinkedList<Employee> addInput() {
		// TODO Auto-generated method stub
		Employee e1 = new Employee(11,"Jyoti","Chaudhary") ;
		Employee e2 = new Employee(12,"Sumit","Kumar") ;
		Employee e3 = new Employee(13,"Amit","Kumar") ;
		LinkedList<Employee> v = new LinkedList<Employee>();
		v .add(e1);
		v.add(e2);
		v.add(e3);
		return v;
	}

	private static void display(LinkedList<Employee> v) {
		// TODO Auto-generated method stub
		for(Employee e:v)
		{
			System.out.println(e.getEmpNo()+"\t"+e.getEmpName()+"\t"+e.getEmpAddress());
		}
	}

}
		

