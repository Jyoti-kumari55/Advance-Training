package com.example.Instrument_array;

public abstract class Instrument 
{
public abstract void Play();
}
