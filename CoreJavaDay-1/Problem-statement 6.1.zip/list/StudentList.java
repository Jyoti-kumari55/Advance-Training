package com.example.array.list;

import java.util.ArrayList;

public class StudentList {
	
	public static void main (String[] args) {
		ArrayList<Integer> student = new ArrayList<>();

	
	student.add(1);
	student.add(2);
	student.add(3);
	student.add(4);
	student.add(5);
	student.add(6);
	student.add(7);
	student.add(8);
		
	
	if(student.indexOf(2)>=0) {
		System.out.println("2 Jyoti exists in the ArrayList");
	}
	else {
		System.out.println("2 Jyoti does not exist in the ArrayList");
	}
	
	if(student.indexOf(4)<0) {
		System.out.println("4 Amit exists in the ArrayList");
	}
	else {
		System.out.println("4 Amit not exist in the ArrayList");
	}
		
	if(student.indexOf(8)>=0) {
		System.out.println("8 Sumit exists in the ArrayList");
	}
	else {
		System.out.println("8 Sumit not exist in the ArrayList");
	}
	if(student.indexOf(9)>0) {
		System.out.println("4 Advika exists in the ArrayList");
	}
	else {
		System.out.println("4 Advika not exist in the ArrayList");
	}
	
	}
}
