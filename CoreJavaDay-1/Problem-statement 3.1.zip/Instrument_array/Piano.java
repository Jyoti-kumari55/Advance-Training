package com.example.Instrument_array;

class Piano extends Instrument{

	public void Play() {
		System.out.println("Piano is playing tan tan tan tan");
	}
}
