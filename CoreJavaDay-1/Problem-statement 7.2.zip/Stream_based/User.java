package com.example.Stream_based;

public class User {

	int rollNo,age;
    String name,address;
    public User() {
		// TODO Auto-generated constructor stub
	}
    {
         rollNo=0;
         name=null;
         age=0;
         address=null;
    }
    User(int r,String n,int a,String c) throws Exception
    {
         rollNo=r;
         address=c;
         int l,temp=0;
         l = n.length();
         for(int i=0;i<l;i++)
         {
              char ch;
              ch=n.charAt(i);
              if(ch<'A' || ch>'Z' && ch<'a' || ch>'z')
                   temp=1;
         }
         /*���-Checking Name�������*/
         try
         {
              if(temp==1)
                   throw new Exception();
              else
                   name=n;
         }
         catch(NameNotValidException e2)
         {
              System.out.println(e2);
         }
         /*���-Checking Age�������*/
         try
         {
              if(a>=15 && a<=25)
                   age=a;
              else
                   throw new Exception();
         }
         catch(AgeNotWithInRangeException e1)
         {
              System.out.println(e1);
         }
    }
    void display()
    {
         System.out.println("roll Name Age Course");
         System.out.println("---------------------");
         System.out.println(rollNo+" , "+name+" , "+age+" , " +address);
    }

}
