package com.example.Stream_based;

import java.io.BufferedReader;
import java.io.InputStreamReader;

public class UserTester {

	public static void main(String args[])throws Exception
    {
         BufferedReader br=new BufferedReader(new InputStreamReader(System.in));

         System.out.print("Enter roll number: ");
         int rollNum = Integer.parseInt(br.readLine());
         System.out.print("\nEnter name: ");
         String name = br.readLine();
         System.out.print("\nEnter age: ");
         int age = Integer.parseInt(br.readLine());
         System.out.print("\nEnter address: ");
         String address = br.readLine();
         User s = new User(rollNum,name,age,address);
         s.display();
    }

}
