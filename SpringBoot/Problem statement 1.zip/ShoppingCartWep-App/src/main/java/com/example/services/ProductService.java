package com.example.services;

import java.util.List;
import org.springframework.stereotype.Service;
import com.example.entity.Product;

@Service
public interface ProductService {

public void addProduct(Product product);
	
	public void FindByProductId(int id);
	
	public void deleteByProductId(int id);
	
	public void updateByProductId(Product product);
	
	public List<Product> allProduct();
	
	public void FindByCategory(String name);
	
}
